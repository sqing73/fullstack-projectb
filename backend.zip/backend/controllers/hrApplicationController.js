// hrApplicationController.js
const EmployeeProfile = require('../models/employeeProfile'); // Ensure this path is correct

exports.getAllEmployeeApplicationInfo = async (req, res) => {
    try {
        const employeeProfiles = await EmployeeProfile.find({});

        const response = employeeProfiles.map(profile => {
            const name = `${profile.name.first} ${profile.name.middle ? profile.name.middle + ' ' : ''}${profile.name.last}`;

            // Log the entire applicationStatus object for debugging
            console.log("Application Status Object: ", profile.applicationStatus);

            let applicationStatus = 'Status Not Available';
            let nextStep = profile.nextStep || 'Next Step Not Available';

            // Adjust the logic here based on the actual structure of applicationStatus
            // ...

            return {
                id: profile._id.toString(), // Convert ObjectId to String
                name: name,
                applicationStatus: applicationStatus,
                nextStep: nextStep
            };
        });

        res.json(response);
    } catch (error) {
        console.error("Error: ", error); // Error logging
        res.status(500).send(error.message);
    }
};
