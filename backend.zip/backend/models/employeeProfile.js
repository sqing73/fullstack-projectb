const mongoose = require('mongoose');

const employeeProfileSchema = new mongoose.Schema({
    name: {
        first: String,
        last: String,
        middle: String,  // Optional, depends if you always have middle name
        preferred: String  // Optional
    },
    personalInfo: {
        ssn: String, 
        // other fields like dob, gender if needed
    },
    residencyStatus: {
        status: String,  // Assuming this is what you mean by work authorization title
        // other fields if needed
    },
    phoneNumbers: {
        cell: String,
        work: String  // Assuming you want to separate cell and work numbers
    },
    email: String,
});

const EmployeeProfile = mongoose.model('EmployeeProfile', employeeProfileSchema, 'employeesProfiles');

module.exports = EmployeeProfile;
