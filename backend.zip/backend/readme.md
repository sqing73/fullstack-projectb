### Installation
Create a `.env` file and add evironment variables as shown in the `.env.example` file.

To generate email password for Gmail, please follow this instruction: https://support.google.com/mail/answer/185833?hl=en